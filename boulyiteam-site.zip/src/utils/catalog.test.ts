import test from 'node:test';
import assert from 'node:assert/strict';
import {
  COLLECTIVE_NAME,
  OFFICIAL_EMAIL,
  HERO_TITLE,
  FLAGSHIP_APPLICATIONS,
  getFlagshipCount,
  findApplicationById,
  verifyApkChecksum,
  validateContactForm,
  generateApkPackageManifest,
  generateStandaloneIndexHtml,
} from './catalog';

test('strictly enforces the unique restriction of exactly two flagship applications with real screenshots', () => {
  assert.equal(getFlagshipCount(), 2);
  const [recette, quickquote] = FLAGSHIP_APPLICATIONS;
  assert.equal(recette.name, 'RecetteFaso');
  assert.equal(quickquote.name, 'QuickQuote PDF');

  // Verify real uploaded screenshot paths are used
  assert.equal(
    recette.logoUrl,
    '/assets/aistudio/Screenshot_20261106-150448_a77c0632.jpg'
  );
  assert.equal(
    recette.imageUrl,
    '/assets/aistudio/Screenshot_20261112-110231_01184fa6.jpg'
  );
  assert.equal(recette.screenshots.length, 9);

  assert.equal(
    quickquote.logoUrl,
    '/assets/aistudio/Screenshot_20261112-062708_291f5c80.jpg'
  );
  assert.equal(
    quickquote.imageUrl,
    '/assets/aistudio/Screenshot_20261112-050845_7379e429.jpg'
  );
  assert.equal(quickquote.screenshots.length, 12);

  for (const app of FLAGSHIP_APPLICATIONS) {
    assert.equal(app.statusBadge, "Prête à l'utilisation / APK disponible");
    for (const shot of app.screenshots) {
      assert.ok(shot.url.startsWith('/assets/aistudio/Screenshot_'));
    }
  }
});

test('verifies required identity and contact constants', () => {
  assert.equal(COLLECTIVE_NAME, 'Boulyi Team Développer');
  assert.equal(OFFICIAL_EMAIL, 'boulyiteamdevelopper@gmail.com');
  assert.equal(HERO_TITLE, 'Bienvenue chez Boulyi Team Développer');
});

test('verifies APK SHA-256 checksum matching', () => {
  const recette = findApplicationById('recette-faso');
  assert.ok(recette);
  const validCheck = verifyApkChecksum(
    'recette-faso',
    `  ${recette.sha256.toUpperCase()} `
  );
  assert.equal(validCheck.matched, true);

  const invalidCheck = verifyApkChecksum('recette-faso', '0000invalidhash');
  assert.equal(invalidCheck.matched, false);
});

test('validates contact form inputs accurately', () => {
  const emptyResult = validateContactForm({
    fullName: '',
    email: 'invalid-email',
    subject: 'Hi',
    applicationTarget: 'RecetteFaso',
    message: 'Too short',
  });
  assert.equal(emptyResult.valid, false);
  assert.ok(emptyResult.errors.fullName);
  assert.ok(emptyResult.errors.email);
  assert.ok(emptyResult.errors.subject);
  assert.ok(emptyResult.errors.message);

  const validResult = validateContactForm({
    fullName: 'Oumar Compaoré',
    email: 'oumar@faso.bf',
    subject: 'Déploiement entreprise QuickQuote PDF',
    applicationTarget: 'QuickQuote PDF',
    message:
      'Bonjour, nous souhaitons équiper nos commerciaux avec QuickQuote PDF.',
  });
  assert.equal(validResult.valid, true);
  assert.deepEqual(validResult.errors, {});
});

test('generates APK manifest and standalone index.html with real screenshot references', () => {
  const quickQuote = findApplicationById('quickquote-pdf')!;
  const manifest = generateApkPackageManifest(quickQuote);
  assert.ok(manifest.includes('QuickQuote PDF'));
  assert.ok(manifest.includes(OFFICIAL_EMAIL));

  const html = generateStandaloneIndexHtml();
  assert.ok(html.includes('<!DOCTYPE html>'));
  assert.ok(html.includes('Bienvenue chez Boulyi Team Développer'));
  assert.ok(html.includes('RecetteFaso'));
  assert.ok(html.includes('QuickQuote PDF'));
  assert.ok(
    html.includes('/assets/aistudio/Screenshot_20261112-110231_01184fa6.jpg')
  );
  assert.ok(
    html.includes('/assets/aistudio/Screenshot_20261112-050845_7379e429.jpg')
  );
  assert.ok(html.includes('boulyiteamdevelopper@gmail.com'));
  assert.ok(html.includes('© 2026 Boulyi Team Développer'));
});
