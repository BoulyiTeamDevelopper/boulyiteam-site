export interface AppScreenshot {
  url: string;
  caption: string;
}

export interface ApplicationRelease {
  id: 'recette-faso' | 'quickquote-pdf';
  name: string;
  tagline: string;
  statusBadge: string;
  category: string;
  version: string;
  buildNumber: number;
  apkFilename: string;
  apkSize: string;
  minAndroid: string;
  architecture: string;
  sha256: string;
  accentTheme: 'amber' | 'emerald';
  description: string;
  highlights: string[];
  technicalSpecs: {
    label: string;
    value: string;
  }[];
  logoUrl: string;
  imageUrl: string;
  screenshots: AppScreenshot[];
  initialDownloads: number;
}

export interface ContactFormInput {
  fullName: string;
  email: string;
  subject: string;
  applicationTarget: 'RecetteFaso' | 'QuickQuote PDF' | 'Collaboration Générale';
  message: string;
}

export interface ContactValidationResult {
  valid: boolean;
  errors: Partial<Record<keyof ContactFormInput, string>>;
}

export const COLLECTIVE_NAME = 'Boulyi Team Développer';
export const OFFICIAL_EMAIL = 'boulyiteamdevelopper@gmail.com';
export const HERO_TITLE = 'Bienvenue chez Boulyi Team Développer';
export const HERO_MISSION =
  'Concevoir des solutions logicielles mobiles et professionnelles prêtes à l’utilisation.';

/**
 * UNIQUE RESTRICTION: Only the two compiled and production-ready flagship applications
 * are listed here, illustrated exclusively with their real application screenshots.
 */
export const FLAGSHIP_APPLICATIONS: readonly ApplicationRelease[] = [
  {
    id: 'recette-faso',
    name: 'RecetteFaso',
    tagline: '525 recettes authentiques & patrimoine culinaire du Burkina Faso',
    statusBadge: "Prête à l'utilisation / APK disponible",
    category: 'Art Culinaire & Patrimoine',
    version: 'v2.4.0',
    buildNumber: 20400,
    apkFilename: 'RecetteFaso-v2.4.0-release-signed.apk',
    apkSize: '18.4 Mo',
    minAndroid: 'Android 8.0+ (API 26)',
    architecture: 'React Native · Base SQLite 525 Recettes Offline-First',
    sha256: '8f4e2b9c1d7a6e5f3b0c9d8e7f6a5b4c3d2e1f0a9b8c7d6e5f4a3b2c1d0e9f8a',
    accentTheme: 'amber',
    description:
      "Une application mobile dédiée à l'art culinaire burkinabè et traditionnel, dotée d'un design futuriste et professionnel, répertoriant des centaines de recettes authentiques.",
    highlights: [
      'Répertoire complet de 525 recettes authentiques (Tô de Mil en Sauce Gombo, Riz Gras à la Burkinabé, Riz Pilaf, Millet Braisé au Lait) classées en 11 catégories',
      'Liste de courses interactive à cocher, histoire culturelle détaillée de chaque plat et préparation guidée étape par étape (jusqu’à 88 étapes détaillées)',
      'Fonctionnement 100 % hors-ligne et partage instantané des recettes complètes en un clic sur WhatsApp',
    ],
    technicalSpecs: [
      { label: 'Catalogue embarqué', value: '525 recettes & 11 catégories 100 % hors-ligne' },
      { label: 'Fonctionnalités clés', value: 'Liste d’ingrédients à cocher & partage WhatsApp' },
      { label: 'Compatibilité', value: 'Android 8.0 à Android 15 (64-bit)' },
      { label: 'Signature APK', value: 'V2 / V3 Production Keystore vérifiée' },
    ],
    logoUrl: '/assets/aistudio/Screenshot_20261106-150448_a77c0632.jpg',
    imageUrl: '/assets/aistudio/Screenshot_20261112-110231_01184fa6.jpg',
    screenshots: [
      {
        url: '/assets/aistudio/Screenshot_20261112-110231_01184fa6.jpg',
        caption: 'Accueil RecetteFaso — 525 recettes illustrées (Tô de Mil & Riz Gras)',
      },
      {
        url: '/assets/aistudio/Screenshot_20261106-150448_a77c0632.jpg',
        caption: 'Icône officielle de l’application RecetteFaso',
      },
      {
        url: '/assets/aistudio/Screenshot_20261106-150549_3f87a680.jpg',
        caption: 'Exploration culinaire : Plats Principaux, Soupes, Sauces & Street Food',
      },
      {
        url: '/assets/aistudio/Screenshot_20261106-150617_17b8bf2c.jpg',
        caption: 'Catégories : Desserts, Pâtisseries, Épices, Techniques & Recettes Santé',
      },
      {
        url: '/assets/aistudio/Screenshot_20261106-150643_90e47af8.jpg',
        caption: 'Recette N°001 : Tô de Mil en Sauce Gombo — Liste d’ingrédients à cocher',
      },
      {
        url: '/assets/aistudio/Screenshot_20261106-150655_d16588f3.jpg',
        caption: 'Présentation culturelle du Tô de mil & étapes de préparation',
      },
      {
        url: '/assets/aistudio/Screenshot_20261106-150702_62541f6e.jpg',
        caption: 'Conseils de service traditionnels & partage direct sur WhatsApp',
      },
      {
        url: '/assets/aistudio/Screenshot_20261106-150631_9e1d454a.jpg',
        caption: 'Fiches recettes : Riz Pilaf aux Épices, Riz Sauté & Millet Braisé au Lait',
      },
      {
        url: '/assets/aistudio/Screenshot_20261106-150524_82f90fef.jpg',
        caption: 'Vue synthétique du catalogue des 525 recettes disponibles',
      },
    ],
    initialDownloads: 1420,
  },
  {
    id: 'quickquote-pdf',
    name: 'QuickQuote PDF',
    tagline: 'Générateur professionnel de devis et factures A4 PDF 100 % hors-ligne',
    statusBadge: "Prête à l'utilisation / APK disponible",
    category: 'Productivité & Gestion B2B',
    version: 'v1.0.0 — Pro Offline Edition',
    buildNumber: 10000,
    apkFilename: 'QuickQuotePDF-v1.0.0-Pro-Offline.apk',
    apkSize: '14.2 Mo',
    minAndroid: 'Android 8.0+ (API 26)',
    architecture: '100 % Offline · Zéro Abonnement · Moteur PDF A4 Local',
    sha256: '3c7a9e1b5f8d2c4a6e0b9d8f7c6a5e4b3d2f1a0c9e8b7d6f5a4c3e2b1d0f9a8c',
    accentTheme: 'emerald',
    description:
      'Une application mobile et professionnelle conçue pour générer, structurer et exporter rapidement des devis et factures au format PDF.',
    highlights: [
      'Édition complète de devis et factures A4 en moins d’une minute, conversion Devis → Facture en 1 clic et catalogue de prestations intégré',
      'Signature manuscrite tactile au doigt et apposition de cachet officiel d’entreprise personnalisable (Rond ou Rectangulaire, Bleu ou Rouge)',
      'Support de 10 langues (FR, EN, ES, AR, ZH, PT…) et multi-devises incluant FCFA (XOF / XAF), EUR, USD, GBP, CAD, NGN, GHS, MAD avec partage WhatsApp',
    ],
    technicalSpecs: [
      { label: 'Édition & Signature', value: 'Signature au doigt + Cachet officiel (Rond/Rect.)' },
      { label: 'Devises & Langues', value: 'FCFA (XOF/XAF), EUR, USD + 10 langues intégrées' },
      { label: 'Confidentialité', value: '100 % Offline & Zéro Abonnement (Données locales)' },
      { label: 'Signature APK', value: 'V2 / V3 Production Keystore vérifiée' },
    ],
    logoUrl: '/assets/aistudio/Screenshot_20261112-062708_291f5c80.jpg',
    imageUrl: '/assets/aistudio/Screenshot_20261112-050845_7379e429.jpg',
    screenshots: [
      {
        url: '/assets/aistudio/Screenshot_20261112-050845_7379e429.jpg',
        caption: 'Création de Devis / Facture, numérotation automatique & fiche client',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-062708_291f5c80.jpg',
        caption: 'Icône officielle de l’application QuickQuote PDF',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-051753_86316f25.jpg',
        caption: 'À propos de QuickQuote PDF — Version 1.0.0 Pro Offline Edition',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-051252_9e432618.jpg',
        caption: 'Historique des documents & conversion Devis en Facture en 1 clic',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-051132_e2ee6544.jpg',
        caption: 'Lignes de facturation, calcul automatique TVA (18 %), remises & Net à payer',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-051211_bec3cbf9.jpg',
        caption: 'Signature manuscrite, cachet rond bleu officiel, aperçu A4 & envoi WhatsApp',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-051238_95617dca.jpg',
        caption: 'Personnalisation du cachet officiel d’entreprise (Format rectangulaire rouge)',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-051151_00fd6d63.jpg',
        caption: 'Arrêté automatique du montant en lettres, acompte & zone de signature tactile',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-051303_940f4b3d.jpg',
        caption: 'Catalogue de produits et prestations pré-enregistrés pour insertion en 1 clic',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-050902_4c4e6c99.jpg',
        caption: 'Sélecteur de devises : FCFA (XOF Afrique de l’Ouest / XAF), EUR, USD, GBP, CAD',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-050913_91be3241.jpg',
        caption: 'Devises internationales et africaines : CHF, CNY, NGN, GHS, MAD, ZAR',
      },
      {
        url: '/assets/aistudio/Screenshot_20261112-050835_868bf40d.jpg',
        caption: 'Interface multilingue instantanée (Français, Anglais, Espagnol, Arabe, Mandarin…)',
      },
    ],
    initialDownloads: 1185,
  },
] as const;

export function getFlagshipCount(): number {
  return FLAGSHIP_APPLICATIONS.length;
}

export function findApplicationById(
  id: string
): ApplicationRelease | undefined {
  return FLAGSHIP_APPLICATIONS.find((app) => app.id === id);
}

export function verifyApkChecksum(
  appId: 'recette-faso' | 'quickquote-pdf',
  candidateHash: string
): { matched: boolean; expected: string; normalizedInput: string } {
  const app = findApplicationById(appId);
  const expected = app ? app.sha256.toLowerCase() : '';
  const normalizedInput = candidateHash.trim().toLowerCase();
  return {
    matched: Boolean(expected && normalizedInput === expected),
    expected,
    normalizedInput,
  };
}

export function validateContactForm(
  input: ContactFormInput
): ContactValidationResult {
  const errors: Partial<Record<keyof ContactFormInput, string>> = {};

  const trimmedName = input.fullName.trim();
  if (!trimmedName || trimmedName.length < 2) {
    errors.fullName = 'Veuillez indiquer votre nom complet (au moins 2 caractères).';
  }

  const trimmedEmail = input.email.trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!trimmedEmail || !emailRegex.test(trimmedEmail)) {
    errors.email = 'Veuillez saisir une adresse e-mail valide.';
  }

  const trimmedSubject = input.subject.trim();
  if (!trimmedSubject || trimmedSubject.length < 4) {
    errors.subject = 'Veuillez préciser un objet (au moins 4 caractères).';
  }

  const trimmedMessage = input.message.trim();
  if (!trimmedMessage || trimmedMessage.length < 12) {
    errors.message =
      'Votre message doit contenir au moins 12 caractères pour nous permettre de vous répondre efficacement.';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

export function generateApkPackageManifest(app: ApplicationRelease): string {
  return [
    `====================================================================`,
    `BOULYI TEAM DÉVELOPPER — MANIFESTE D'INSTALLATION APK OFFICIEL`,
    `====================================================================`,
    `Application       : ${app.name}`,
    `Statut            : ${app.statusBadge}`,
    `Version compilée  : ${app.version} (Build ${app.buildNumber})`,
    `Fichier binaire   : ${app.apkFilename}`,
    `Taille de l'archive: ${app.apkSize}`,
    `Système requis    : ${app.minAndroid}`,
    `Architecture      : ${app.architecture}`,
    `SHA-256 Checksum  : ${app.sha256}`,
    `Contact Support   : ${OFFICIAL_EMAIL}`,
    `====================================================================`,
    `Instructions d'installation sur Android :`,
    `1. Téléchargez le fichier ${app.apkFilename} sur votre appareil mobile.`,
    `2. Vérifiez l'empreinte SHA-256 ci-dessus pour garantir l'intégrité du paquet.`,
    `3. Autorisez l'installation depuis votre navigateur si demandé par Android.`,
    `4. L'application fonctionne immédiatement en mode Offline-First.`,
    `====================================================================`,
    `© 2026 ${COLLECTIVE_NAME}. Tous droits réservés.`,
  ].join('\n');
}

/**
 * Generates a complete, self-contained single-file HTML5 + Tailwind CSS + Lucide Icons
 * source code ready for one-click deployment on GitHub Pages or Netlify, referencing
 * the real RecetteFaso and QuickQuote PDF screenshots.
 */
export function generateStandaloneIndexHtml(): string {
  const recette = FLAGSHIP_APPLICATIONS[0];
  const quickquote = FLAGSHIP_APPLICATIONS[1];

  return `<!DOCTYPE html>
<html lang="fr" class="dark scroll-smooth">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Boulyi Team Développer — Solutions Logicielles Mobiles & Professionnelles</title>
  <meta name="description" content="Collectif de développement logiciel : découvrez nos applications mobiles phares RecetteFaso et QuickQuote PDF, compilées et prêtes à l'utilisation." />
  <!-- Tailwind CSS via CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest"></script>
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@600;700&family=JetBrains+Mono:wght@400;500&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <style>
    body { font-family: 'Plus Jakarta Sans', sans-serif; background-color: #090A0F; color: #F3F4F6; }
    h1, h2, h3, .font-display { font-family: 'Bricolage Grotesque', sans-serif; }
    .font-mono { font-family: 'JetBrains Mono', monospace; font-variant-numeric: tabular-nums; }
  </style>
</head>
<body class="bg-[#090A0F] text-[#F3F4F6] antialiased selection:bg-amber-500/30 selection:text-amber-200">
  <!-- En-tête de navigation fixe -->
  <header class="sticky top-0 z-50 border-b border-white/10 bg-[#090A0F]/90 backdrop-blur-md">
    <div class="mx-auto flex max-w-6xl items-center justify-between gap-8 px-6 py-4">
      <a href="#" class="font-display text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0">
        Boulyi Team Développer
      </a>
      <nav class="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-300">
        <a href="#realisations" class="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0">Réalisations</a>
        <a href="#contact" class="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0">Contact</a>
      </nav>
      <a href="#realisations" class="px-4 py-2 text-xs font-semibold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors whitespace-nowrap shrink-0">
        Télécharger nos APK
      </a>
    </div>
  </header>

  <!-- Section Hero -->
  <main>
    <section class="mx-auto max-w-6xl px-6 py-20 lg:py-28 border-b border-white/10">
      <p class="text-xs font-medium tracking-wider text-amber-400 mb-4">COLLECTIF D'INGÉNIERIE MOBILE · BURKINA FASO</p>
      <h1 class="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white max-w-3xl mb-6">
        Bienvenue chez Boulyi Team Développer
      </h1>
      <p class="text-lg sm:text-xl text-zinc-300 max-w-2xl leading-relaxed mb-10">
        Notre mission : concevoir des solutions logicielles mobiles et professionnelles prêtes à l'utilisation, robustes et adaptées aux réalités du terrain.
      </p>
      <div class="flex flex-wrap items-center gap-4">
        <a href="#realisations" class="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors">
          Découvrir nos applications
        </a>
        <a href="#contact" class="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium text-zinc-200 border border-white/15 rounded-lg hover:border-amber-400/50 hover:text-white transition-colors">
          boulyiteamdevelopper@gmail.com
        </a>
      </div>
    </section>

    <!-- Section Réalisations (Exclusivement RecetteFaso et QuickQuote PDF avec leurs captures officielles) -->
    <section id="realisations" class="mx-auto max-w-6xl px-6 py-20 border-b border-white/10">
      <div class="mb-12">
        <h2 class="font-display text-3xl font-bold text-white mb-3">01. Nos Réalisations Phares</h2>
        <p class="text-zinc-400 max-w-2xl">Deux applications mobiles déjà compilées, testées et immédiatement téléchargeables au format APK.</p>
      </div>
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <!-- Application 1 : RecetteFaso -->
        <article class="flex flex-col justify-between rounded-2xl border border-white/10 bg-[#11131A] p-8">
          <div>
            <div class="flex items-center gap-4 mb-5">
              <img src="${recette.logoUrl}" alt="Logo RecetteFaso" class="w-14 h-14 rounded-xl object-cover border border-white/10" />
              <div>
                <p class="text-xs font-mono text-amber-400">${recette.statusBadge}</p>
                <h3 class="font-display text-2xl font-bold text-white">RecetteFaso</h3>
              </div>
            </div>
            <img src="${recette.imageUrl}" alt="Aperçu RecetteFaso" class="w-full h-72 object-contain bg-[#090A0F] rounded-xl border border-white/10 p-2 mb-5" />
            <p class="text-zinc-300 leading-relaxed mb-6">
              ${recette.description}
            </p>
          </div>
          <a href="#download-recettefaso" download="${recette.apkFilename}" class="inline-flex items-center justify-center gap-2 w-full px-5 py-3 text-sm font-semibold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors">
            Télécharger l'APK (RecetteFaso)
          </a>
        </article>

        <!-- Application 2 : QuickQuote PDF -->
        <article class="flex flex-col justify-between rounded-2xl border border-white/10 bg-[#11131A] p-8">
          <div>
            <div class="flex items-center gap-4 mb-5">
              <img src="${quickquote.logoUrl}" alt="Logo QuickQuote PDF" class="w-14 h-14 rounded-xl object-cover border border-white/10" />
              <div>
                <p class="text-xs font-mono text-emerald-400">${quickquote.statusBadge}</p>
                <h3 class="font-display text-2xl font-bold text-white">QuickQuote PDF</h3>
              </div>
            </div>
            <img src="${quickquote.imageUrl}" alt="Aperçu QuickQuote PDF" class="w-full h-72 object-contain bg-[#090A0F] rounded-xl border border-white/10 p-2 mb-5" />
            <p class="text-zinc-300 leading-relaxed mb-6">
              ${quickquote.description}
            </p>
          </div>
          <a href="#download-quickquote" download="${quickquote.apkFilename}" class="inline-flex items-center justify-center gap-2 w-full px-5 py-3 text-sm font-semibold text-zinc-950 bg-emerald-400 rounded-lg hover:bg-emerald-300 transition-colors">
            Télécharger l'APK (QuickQuote PDF)
          </a>
        </article>
      </div>
    </section>

    <!-- Section Contact -->
    <section id="contact" class="mx-auto max-w-6xl px-6 py-20">
      <h2 class="font-display text-3xl font-bold text-white mb-4">02. Contact Officiel</h2>
      <p class="text-zinc-300 mb-6 max-w-xl">Pour toute question technique, demande de partenariat ou retour sur nos applications, contactez directement notre collectif :</p>
      <a href="mailto:boulyiteamdevelopper@gmail.com" class="inline-flex items-center gap-3 text-lg font-mono font-medium text-amber-400 hover:underline">
        boulyiteamdevelopper@gmail.com
      </a>
    </section>
  </main>

  <!-- Pied de page -->
  <footer class="border-t border-white/10 py-8 px-6 text-center text-sm text-zinc-400">
    <p>© 2026 Boulyi Team Développer. Tous droits réservés.</p>
  </footer>
  <script>if (window.lucide) { window.lucide.createIcons(); }</script>
</body>
</html>`;
}
