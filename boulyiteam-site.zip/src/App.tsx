/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CheckCircle2, X } from 'lucide-react';
import {
  FLAGSHIP_APPLICATIONS,
  ApplicationRelease,
  generateApkPackageManifest,
} from './utils/catalog';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { RealisationsSection } from './components/RealisationsSection';
import { EngineeringSection } from './components/EngineeringSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { ApkInspectorModal } from './components/ApkInspectorModal';
import { StandaloneHtmlModal } from './components/StandaloneHtmlModal';

export default function App() {
  const [downloadCounts, setDownloadCounts] = useState<Record<string, number>>({
    'recette-faso': FLAGSHIP_APPLICATIONS[0].initialDownloads,
    'quickquote-pdf': FLAGSHIP_APPLICATIONS[1].initialDownloads,
  });
  const [recentDownloadedApp, setRecentDownloadedApp] =
    useState<ApplicationRelease | null>(null);
  const [inspectedApp, setInspectedApp] = useState<ApplicationRelease | null>(
    null
  );
  const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);

  const totalDownloads = Object.values(downloadCounts).reduce(
    (acc, val) => acc + val,
    0
  );

  const handleDownloadApk = (app: ApplicationRelease) => {
    setDownloadCounts((prev) => ({
      ...prev,
      [app.id]: (prev[app.id] ?? app.initialDownloads) + 1,
    }));
    setRecentDownloadedApp(app);

    // Trigger immediate client download of the signed APK manifest & installer receipt
    try {
      const manifestText = generateApkPackageManifest(app);
      const blob = new Blob([manifestText], {
        type: 'application/vnd.android.package-archive',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = app.apkFilename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch {
      // Fallback if blob download is blocked in headless environment
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#090A0F] text-[#F3F4F6]">
      <Navbar onOpenCodeModal={() => setIsCodeModalOpen(true)} />

      {/* Non-intrusive APK download confirmation bar when triggered */}
      {recentDownloadedApp && (
        <div
          role="status"
          data-testid="apk-download-notification"
          className="border-b border-amber-400/30 bg-[#141722] px-6 py-3"
        >
          <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-4 text-xs">
            <div className="flex flex-wrap items-center gap-2 text-zinc-200">
              <CheckCircle2
                className="w-4 h-4 text-amber-400 shrink-0"
                aria-hidden="true"
              />
              <span>
                Téléchargement lancé :{' '}
                <strong className="font-mono text-white">
                  {recentDownloadedApp.apkFilename}
                </strong>{' '}
                ({recentDownloadedApp.apkSize}) · SHA-256 :{' '}
                <code className="font-mono text-amber-300">
                  {recentDownloadedApp.sha256.slice(0, 16)}…
                </code>
              </span>
            </div>
            <button
              type="button"
              onClick={() => setRecentDownloadedApp(null)}
              aria-label="Fermer la notification de téléchargement"
              className="text-zinc-400 hover:text-white p-1 cursor-pointer"
            >
              <X className="w-4 h-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      )}

      <main className="flex-1">
        <HeroSection
          onOpenCodeModal={() => setIsCodeModalOpen(true)}
          totalDownloads={totalDownloads}
        />

        <RealisationsSection
          downloadCounts={downloadCounts}
          recentDownloadedId={recentDownloadedApp?.id ?? null}
          onDownloadApk={handleDownloadApk}
          onInspectApk={(app) => setInspectedApp(app)}
        />

        <EngineeringSection />

        <ContactSection />
      </main>

      <Footer onOpenCodeModal={() => setIsCodeModalOpen(true)} />

      <ApkInspectorModal
        app={inspectedApp}
        onClose={() => setInspectedApp(null)}
        onDownloadApk={handleDownloadApk}
      />

      <StandaloneHtmlModal
        isOpen={isCodeModalOpen}
        onClose={() => setIsCodeModalOpen(false)}
      />
    </div>
  );
}

