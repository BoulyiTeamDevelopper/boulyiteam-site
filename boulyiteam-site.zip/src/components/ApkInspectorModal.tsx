import React, { useState } from 'react';
import {
  X,
  Download,
  ShieldCheck,
  Copy,
  Check,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import {
  ApplicationRelease,
  verifyApkChecksum,
} from '../utils/catalog';

interface ApkInspectorModalProps {
  app: ApplicationRelease | null;
  onClose: () => void;
  onDownloadApk: (app: ApplicationRelease) => void;
}

export const ApkInspectorModal: React.FC<ApkInspectorModalProps> = ({
  app,
  onClose,
  onDownloadApk,
}) => {
  const [copiedHash, setCopiedHash] = useState(false);
  const [candidateHash, setCandidateHash] = useState('');

  if (!app) return null;

  const isAmber = app.accentTheme === 'amber';
  const checkResult = candidateHash.trim()
    ? verifyApkChecksum(app.id, candidateHash)
    : null;

  const handleCopySha = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(app.sha256);
      }
    } catch {
      // ignore clipboard errors in restricted environments
    }
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="apk-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto"
    >
      <div className="relative w-full max-w-2xl rounded-2xl border border-white/15 bg-[#11131A] p-6 sm:p-8 shadow-2xl">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <p
              className={`text-xs font-mono font-semibold mb-1 ${
                isAmber ? 'text-amber-400' : 'text-emerald-400'
              }`}
            >
              {app.statusBadge} · {app.version}
            </p>
            <h2
              id="apk-modal-title"
              className="font-display text-2xl font-bold text-white"
            >
              Fiche Technique &amp; Intégrité APK — {app.name}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer la fiche technique"
            className="rounded-lg border border-white/15 bg-[#161923] p-2 text-zinc-300 hover:border-white/30 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        {/* Technical Specs & SHA-256 Verifier separated by clean hairline dividers */}
        <div className="py-6 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-5 border-b border-white/10 pb-6">
            {app.technicalSpecs.map((spec, idx) => (
              <div key={idx}>
                <span className="block text-xs text-zinc-400 mb-1">
                  {spec.label}
                </span>
                <span className="font-medium text-sm text-white">
                  {spec.value}
                </span>
              </div>
            ))}
          </div>

          {/* SHA-256 Checksum Display & Verifier */}
          <div>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
              <div className="flex items-center gap-2 text-xs font-mono text-zinc-300">
                <ShieldCheck
                  className={`w-4 h-4 ${
                    isAmber ? 'text-amber-400' : 'text-emerald-400'
                  }`}
                  aria-hidden="true"
                />
                <span>EMPREINTE SHA-256 OFFICIELLE ({app.apkFilename})</span>
              </div>
              <button
                type="button"
                onClick={handleCopySha}
                className="inline-flex items-center gap-1.5 text-xs font-mono text-amber-400 hover:text-amber-300 cursor-pointer"
              >
                {copiedHash ? (
                  <>
                    <Check className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Copiée</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Copier le SHA-256</span>
                  </>
                )}
              </button>
            </div>

            <code className="block w-full break-all rounded-lg bg-[#090A0F] p-3.5 text-xs font-mono text-zinc-200 mb-5">
              {app.sha256}
            </code>

            <label
              htmlFor="verify-sha-input"
              className="block text-xs text-zinc-400 mb-2"
            >
              Vérificateur d’empreinte (collez un hash SHA-256 pour contrôler l’authenticité de votre fichier APK) :
            </label>
            <div className="flex flex-col sm:flex-row gap-2.5">
              <input
                id="verify-sha-input"
                type="text"
                value={candidateHash}
                onChange={(e) => setCandidateHash(e.target.value)}
                placeholder="Collez une empreinte SHA-256 à comparer..."
                className="flex-1 rounded-lg border border-white/15 bg-[#090A0F] px-3.5 py-2.5 text-xs font-mono text-white placeholder:text-zinc-500 focus:border-amber-400 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setCandidateHash(app.sha256)}
                className="px-3.5 py-2.5 text-xs font-medium text-zinc-200 bg-[#161923] border border-white/15 rounded-lg hover:border-white/30 cursor-pointer whitespace-nowrap shrink-0"
              >
                Tester avec le hash officiel
              </button>
            </div>

            {checkResult && (
              <div
                className={`mt-3 flex items-center gap-2 text-xs font-medium ${
                  checkResult.matched ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                {checkResult.matched ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>
                      Empreinte SHA-256 authentique : le paquet {app.apkFilename}{' '}
                      est certifié par Boulyi Team Développer.
                    </span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>
                      L’empreinte saisie ne correspond pas au binaire officiel{' '}
                      {app.version}.
                    </span>
                  </>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex flex-wrap items-center justify-end gap-3 border-t border-white/10 pt-5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 text-xs font-medium text-zinc-300 border border-white/15 rounded-lg hover:text-white cursor-pointer"
          >
            Fermer
          </button>

          <button
            type="button"
            onClick={() => onDownloadApk(app)}
            className={`inline-flex items-center gap-2 px-5 py-2.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              isAmber
                ? 'bg-amber-400 text-zinc-950 hover:bg-amber-300'
                : 'bg-emerald-400 text-zinc-950 hover:bg-emerald-300'
            }`}
          >
            <Download className="w-4 h-4" aria-hidden="true" />
            <span>
              Télécharger {app.apkFilename} ({app.apkSize})
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
