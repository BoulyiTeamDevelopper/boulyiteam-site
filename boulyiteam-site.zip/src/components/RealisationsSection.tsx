import React, { useState } from 'react';
import {
  Download,
  CheckCircle2,
  Shield,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  X,
} from 'lucide-react';
import {
  FLAGSHIP_APPLICATIONS,
  ApplicationRelease,
} from '../utils/catalog';

interface RealisationsSectionProps {
  downloadCounts: Record<string, number>;
  recentDownloadedId: string | null;
  onDownloadApk: (app: ApplicationRelease) => void;
  onInspectApk: (app: ApplicationRelease) => void;
}

export const RealisationsSection: React.FC<RealisationsSectionProps> = ({
  downloadCounts,
  recentDownloadedId,
  onDownloadApk,
  onInspectApk,
}) => {
  const [activeSlideIndex, setActiveSlideIndex] = useState<
    Record<string, number>
  >({
    'recette-faso': 0,
    'quickquote-pdf': 0,
  });

  const [lightboxState, setLightboxState] = useState<{
    app: ApplicationRelease;
    index: number;
  } | null>(null);

  const handleStepSlide = (app: ApplicationRelease, delta: number) => {
    setActiveSlideIndex((prev) => {
      const current = prev[app.id] ?? 0;
      const total = app.screenshots.length;
      const next = (current + delta + total) % total;
      return { ...prev, [app.id]: next };
    });
  };

  return (
    <section
      id="realisations"
      aria-labelledby="realisations-heading"
      className="border-b border-white/10 bg-[#090A0F] py-20 lg:py-28"
    >
      <div className="mx-auto max-w-[1200px] px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div>
            <p className="text-xs font-medium text-amber-400 mb-2">
              CATALOGUE OFFICIEL · BINAIRES COMPILÉS &amp; CAPTURES RÉELLES
            </p>
            <h2
              id="realisations-heading"
              className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white"
              style={{ textWrap: 'balance' }}
            >
              01. Nos Réalisations Phares
            </h2>
          </div>
          <p className="text-sm text-zinc-400 max-w-md leading-relaxed">
            Nous présentons exclusivement nos deux applications mobiles abouties,
            illustrées par leurs captures d’écran officielles et prêtes à être
            installées dès maintenant.
          </p>
        </div>

        {/* Strictly 2 Flagship Applications Grid */}
        <div
          data-testid="flagship-apps-grid"
          className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-stretch"
        >
          {FLAGSHIP_APPLICATIONS.map((app) => {
            const isAmber = app.accentTheme === 'amber';
            const isJustDownloaded = recentDownloadedId === app.id;
            const currentCount =
              downloadCounts[app.id] ?? app.initialDownloads;
            const currentIdx = activeSlideIndex[app.id] ?? 0;
            const activeShot =
              app.screenshots[currentIdx] ?? app.screenshots[0];

            return (
              <article
                key={app.id}
                data-testid={`app-card-${app.id}`}
                className="flex flex-col justify-between rounded-2xl border border-white/10 bg-[#11131A] overflow-hidden transition-colors hover:border-white/20"
              >
                <div>
                  {/* Interactive Real App Screenshot Carousel & Thumbnail Strip */}
                  <div className="border-b border-white/10 bg-[#0C0E14] p-5 sm:p-6">
                    {/* Top Bar inside Showcase: Official Icon + Slide Counter + Fullscreen Button */}
                    <div className="flex items-center justify-between gap-3 mb-4">
                      <div className="flex items-center gap-3 min-w-0">
                        <img
                          src={app.logoUrl}
                          alt={`Logo officiel ${app.name}`}
                          referrerPolicy="no-referrer"
                          className="w-11 h-11 rounded-xl object-cover border border-white/15 shrink-0"
                        />
                        <div className="min-w-0">
                          <span className="block font-display text-lg font-bold text-white truncate">
                            {app.name}
                          </span>
                          <span className="block text-xs font-mono text-zinc-400 truncate">
                            {app.version} · {app.apkSize}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <span className="font-mono text-xs text-zinc-400 tabular-nums">
                          {currentIdx + 1} / {app.screenshots.length}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setLightboxState({ app, index: currentIdx })
                          }
                          aria-label={`Agrandir la capture d'écran de ${app.name}`}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-zinc-200 bg-[#161923] border border-white/15 rounded-lg hover:border-white/30 hover:text-white transition-colors cursor-pointer"
                        >
                          <Maximize2 className="w-3.5 h-3.5" aria-hidden="true" />
                          <span>Plein écran</span>
                        </button>
                      </div>
                    </div>

                    {/* Main Screenshot Viewport */}
                    <div className="relative flex items-center justify-center rounded-xl bg-[#090A0F] h-[360px] sm:h-[400px] overflow-hidden p-3">
                      <img
                        src={activeShot.url}
                        alt={activeShot.caption}
                        referrerPolicy="no-referrer"
                        onClick={() =>
                          setLightboxState({ app, index: currentIdx })
                        }
                        className="max-h-full w-auto object-contain rounded-lg cursor-zoom-in"
                      />

                      {/* Prev / Next Controls */}
                      <button
                        type="button"
                        onClick={() => handleStepSlide(app, -1)}
                        aria-label={`Capture précédente de ${app.name}`}
                        className="absolute left-3 top-1/2 -translate-y-1/2 rounded-lg border border-white/15 bg-[#11131A]/90 p-2 text-zinc-200 hover:border-white/40 hover:text-white transition-colors cursor-pointer"
                      >
                        <ChevronLeft className="w-4 h-4" aria-hidden="true" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleStepSlide(app, 1)}
                        aria-label={`Capture suivante de ${app.name}`}
                        className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg border border-white/15 bg-[#11131A]/90 p-2 text-zinc-200 hover:border-white/40 hover:text-white transition-colors cursor-pointer"
                      >
                        <ChevronRight className="w-4 h-4" aria-hidden="true" />
                      </button>
                    </div>

                    {/* Active Screenshot Caption */}
                    <p className="mt-3 text-xs text-zinc-300 text-center font-medium min-h-[1.25rem]">
                      {activeShot.caption}
                    </p>

                    {/* Thumbnail Selector Strip for all uploaded screenshots */}
                    <div
                      role="group"
                      aria-label={`Miniatures des captures de ${app.name}`}
                      className="mt-3 flex items-center gap-2 overflow-x-auto pb-1"
                    >
                      {app.screenshots.map((shot, idx) => {
                        const isSelected = idx === currentIdx;
                        return (
                          <button
                            key={shot.url}
                            type="button"
                            onClick={() =>
                              setActiveSlideIndex((prev) => ({
                                ...prev,
                                [app.id]: idx,
                              }))
                            }
                            aria-label={`Afficher la capture ${idx + 1} de ${app.name} : ${shot.caption}`}
                            className={`relative h-14 w-10 shrink-0 overflow-hidden rounded-md border transition-all cursor-pointer ${
                              isSelected
                                ? isAmber
                                  ? 'border-amber-400 ring-1 ring-amber-400'
                                  : 'border-emerald-400 ring-1 ring-emerald-400'
                                : 'border-white/15 opacity-60 hover:opacity-100'
                            }`}
                          >
                            <img
                              src={shot.url}
                              alt=""
                              referrerPolicy="no-referrer"
                              className="h-full w-full object-cover object-top"
                            />
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-6 sm:p-8">
                    {/* Required Status Display — Clean Unboxed Metadata per Zero-Pill Discipline */}
                    <div className="flex flex-wrap items-center gap-2 text-xs font-mono mb-3">
                      <CheckCircle2
                        className={`w-4 h-4 shrink-0 ${
                          isAmber ? 'text-amber-400' : 'text-emerald-400'
                        }`}
                        aria-hidden="true"
                      />
                      <span
                        className={`font-semibold ${
                          isAmber ? 'text-amber-400' : 'text-emerald-400'
                        }`}
                      >
                        {app.statusBadge}
                      </span>
                      <span className="text-zinc-500" aria-hidden="true">
                        ·
                      </span>
                      <span className="text-zinc-400">{app.minAndroid}</span>
                    </div>

                    {/* App Name & Tagline */}
                    <h3 className="font-display text-2xl sm:text-3xl font-bold text-white mb-2">
                      {app.name}
                    </h3>
                    <p className="text-xs font-medium text-zinc-400 mb-4">
                      {app.tagline}
                    </p>

                    {/* Core Description */}
                    <p className="text-sm sm:text-base text-zinc-300 leading-relaxed mb-6">
                      {app.description}
                    </p>

                    {/* Functional Highlights */}
                    <div className="border-t border-white/10 pt-5 mb-6">
                      <p className="text-xs font-semibold text-zinc-200 mb-3">
                        Points clés de la version compilée :
                      </p>
                      <ul className="space-y-2.5 text-sm text-zinc-300">
                        {app.highlights.map((item, idx) => (
                          <li key={idx} className="flex items-start gap-2.5">
                            <span
                              className={`font-mono text-xs mt-1 shrink-0 ${
                                isAmber ? 'text-amber-400' : 'text-emerald-400'
                              }`}
                              aria-hidden="true"
                            >
                              0{idx + 1}.
                            </span>
                            <span className="leading-relaxed">{item}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Compact Technical Metadata Row */}
                    <div className="border-t border-white/10 pt-4 grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <span className="text-zinc-400 block">
                          Fichier binaire
                        </span>
                        <span className="font-mono text-zinc-200 truncate block mt-0.5">
                          {app.apkFilename}
                        </span>
                      </div>
                      <div>
                        <span className="text-zinc-400 block">
                          Téléchargements
                        </span>
                        <span
                          data-testid={`download-count-${app.id}`}
                          className="font-mono text-zinc-200 tabular-nums block mt-0.5"
                        >
                          {currentCount.toLocaleString('fr-FR')} installations
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Footer: Stylized APK Download CTA & Checksum Inspector */}
                <div className="px-6 pb-6 sm:px-8 sm:pb-8 pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <button
                    type="button"
                    onClick={() => onDownloadApk(app)}
                    className={`flex-1 inline-flex items-center justify-center gap-2.5 px-5 py-3.5 text-sm font-semibold rounded-lg transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                      isAmber
                        ? 'bg-amber-400 text-zinc-950 hover:bg-amber-300'
                        : 'bg-emerald-400 text-zinc-950 hover:bg-emerald-300'
                    }`}
                  >
                    <Download className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>
                      {isJustDownloaded
                        ? `APK ${app.name} téléchargé`
                        : `Télécharger l'APK (${app.apkSize})`}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onInspectApk(app)}
                    className="inline-flex items-center justify-center gap-2 px-4 py-3.5 text-xs font-medium text-zinc-200 bg-[#161923] border border-white/15 rounded-lg hover:border-white/30 hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <Shield className="w-4 h-4 text-zinc-400" aria-hidden="true" />
                    <span>Fiche &amp; SHA-256</span>
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      </div>

      {/* Fullscreen Lightbox Modal for Inspecting Real Screenshots */}
      {lightboxState && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={`Galerie plein écran — ${lightboxState.app.name}`}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4"
        >
          <div className="relative flex flex-col w-full max-w-4xl max-h-[92vh] rounded-2xl border border-white/15 bg-[#11131A] p-4 sm:p-6">
            <div className="flex items-center justify-between gap-4 pb-4 border-b border-white/10">
              <div className="flex items-center gap-3 min-w-0">
                <img
                  src={lightboxState.app.logoUrl}
                  alt={lightboxState.app.name}
                  className="w-9 h-9 rounded-lg object-cover shrink-0"
                />
                <div className="min-w-0">
                  <h3 className="font-display text-base sm:text-lg font-bold text-white truncate">
                    {lightboxState.app.name} — Capture{' '}
                    {lightboxState.index + 1} sur{' '}
                    {lightboxState.app.screenshots.length}
                  </h3>
                  <p className="text-xs text-zinc-300 truncate">
                    {lightboxState.app.screenshots[lightboxState.index]?.caption}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setLightboxState(null)}
                aria-label="Fermer l'aperçu plein écran"
                className="rounded-lg border border-white/15 bg-[#161923] p-2 text-zinc-300 hover:border-white/30 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            <div className="relative flex-1 flex items-center justify-center overflow-hidden my-4 min-h-[320px] max-h-[68vh] bg-[#090A0F] rounded-xl p-3">
              <img
                src={lightboxState.app.screenshots[lightboxState.index]?.url}
                alt={lightboxState.app.screenshots[lightboxState.index]?.caption}
                className="max-h-full w-auto object-contain rounded-lg"
              />

              <button
                type="button"
                onClick={() =>
                  setLightboxState((prev) =>
                    prev
                      ? {
                          ...prev,
                          index:
                            (prev.index - 1 + prev.app.screenshots.length) %
                            prev.app.screenshots.length,
                        }
                      : null
                  )
                }
                aria-label="Capture précédente"
                className="absolute left-3 top-1/2 -translate-y-1/2 rounded-lg border border-white/15 bg-[#11131A]/90 p-2.5 text-white hover:border-white/40 cursor-pointer"
              >
                <ChevronLeft className="w-5 h-5" aria-hidden="true" />
              </button>

              <button
                type="button"
                onClick={() =>
                  setLightboxState((prev) =>
                    prev
                      ? {
                          ...prev,
                          index:
                            (prev.index + 1) % prev.app.screenshots.length,
                        }
                      : null
                  )
                }
                aria-label="Capture suivante"
                className="absolute right-3 top-1/2 -translate-y-1/2 rounded-lg border border-white/15 bg-[#11131A]/90 p-2.5 text-white hover:border-white/40 cursor-pointer"
              >
                <ChevronRight className="w-5 h-5" aria-hidden="true" />
              </button>
            </div>

            <div className="flex items-center justify-center gap-2 overflow-x-auto pt-2">
              {lightboxState.app.screenshots.map((shot, idx) => (
                <button
                  key={shot.url}
                  type="button"
                  onClick={() =>
                    setLightboxState((prev) =>
                      prev ? { ...prev, index: idx } : null
                    )
                  }
                  aria-label={`Aller à la capture ${idx + 1}`}
                  className={`h-12 w-9 shrink-0 overflow-hidden rounded border transition-all cursor-pointer ${
                    idx === lightboxState.index
                      ? 'border-amber-400 ring-1 ring-amber-400'
                      : 'border-white/15 opacity-50 hover:opacity-100'
                  }`}
                >
                  <img
                    src={shot.url}
                    alt=""
                    className="h-full w-full object-cover object-top"
                  />
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
