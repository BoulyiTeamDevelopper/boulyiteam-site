import React from 'react';
import { COLLECTIVE_NAME, OFFICIAL_EMAIL } from '../utils/catalog';

interface FooterProps {
  onOpenCodeModal: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenCodeModal }) => {
  return (
    <footer className="border-t border-white/10 bg-[#090A0F] py-12">
      <div className="mx-auto max-w-[1200px] px-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 pb-8 border-b border-white/10">
          <div>
            <p className="font-display text-lg font-bold text-white">
              {COLLECTIVE_NAME}
            </p>
            <p className="text-xs text-zinc-400 mt-1">
              Solutions logicielles mobiles et professionnelles prêtes à l’utilisation · Burkina Faso
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs font-medium text-zinc-300">
            <a href="#accueil" className="hover:text-amber-400 transition-colors">
              Accueil
            </a>
            <a href="#realisations" className="hover:text-amber-400 transition-colors">
              Réalisations (RecetteFaso &amp; QuickQuote PDF)
            </a>
            <a href="#ingenierie" className="hover:text-amber-400 transition-colors">
              Ingénierie Offline-First
            </a>
            <button
              type="button"
              onClick={onOpenCodeModal}
              className="hover:text-amber-400 transition-colors cursor-pointer"
            >
              Exporter index.html
            </button>
            <a
              href={`mailto:${OFFICIAL_EMAIL}`}
              className="font-mono text-amber-400 hover:underline"
            >
              {OFFICIAL_EMAIL}
            </a>
          </div>
        </div>

        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-zinc-400">
          <p>© 2026 {COLLECTIVE_NAME}. Tous droits réservés.</p>
          <p className="font-mono">
            Applications compilées : RecetteFaso v2.4.0 · QuickQuote PDF v1.0.0 Pro Offline
          </p>
        </div>
      </div>
    </footer>
  );
};
