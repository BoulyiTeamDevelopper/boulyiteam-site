import React from 'react';
import { COLLECTIVE_NAME } from '../utils/catalog';

interface NavbarProps {
  onOpenCodeModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenCodeModal }) => {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#090A0F]/95 backdrop-blur-md">
      <div className="mx-auto flex max-w-[1200px] items-center justify-between gap-4 md:gap-8 px-4 sm:px-6 py-3.5 sm:py-4">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#accueil"
          className="font-display text-base sm:text-lg font-bold tracking-tight text-white hover:text-amber-400 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-amber-400"
        >
          {COLLECTIVE_NAME}
        </a>

        {/* Zone 2: 4 concise single-line text navigation links */}
        <nav
          aria-label="Navigation principale"
          className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-300"
        >
          <a
            href="#realisations"
            className="hover:text-white hover:underline underline-offset-8 decoration-amber-400 transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Réalisations
          </a>
          <a
            href="#ingenierie"
            className="hover:text-white hover:underline underline-offset-8 decoration-amber-400 transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Ingénierie
          </a>
          <button
            type="button"
            onClick={onOpenCodeModal}
            className="hover:text-white hover:underline underline-offset-8 decoration-amber-400 transition-colors whitespace-nowrap shrink-0 py-1 cursor-pointer"
          >
            Code HTML5
          </button>
          <a
            href="#contact"
            className="hover:text-white hover:underline underline-offset-8 decoration-amber-400 transition-colors whitespace-nowrap shrink-0 py-1"
          >
            Contact
          </a>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <a
            href="#realisations"
            className="px-3.5 sm:px-4 py-2 text-xs font-semibold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-400"
          >
            Télécharger nos APK
          </a>
        </div>
      </div>
    </header>
  );
};
