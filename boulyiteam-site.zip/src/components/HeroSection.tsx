import React from 'react';
import { ArrowDownRight, FileCode2, ShieldCheck } from 'lucide-react';
import {
  HERO_TITLE,
  HERO_MISSION,
  OFFICIAL_EMAIL,
  FLAGSHIP_APPLICATIONS,
} from '../utils/catalog';

interface HeroSectionProps {
  onOpenCodeModal: () => void;
  totalDownloads: number;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenCodeModal,
  totalDownloads,
}) => {
  const [recetteApp, quickQuoteApp] = FLAGSHIP_APPLICATIONS;

  return (
    <section
      id="accueil"
      className="border-b border-white/10 bg-[#090A0F] pt-12 pb-16 lg:pt-20 lg:pb-24"
    >
      <div className="mx-auto max-w-[1200px] px-6">
        {/* 2-Column Hero Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left Column: Typographic Hierarchy & Mission */}
          <div className="lg:col-span-7 flex flex-col justify-between">
            <div>
              <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-amber-400 mb-5">
                <span>Collectif de Développement Logiciel</span>
                <span aria-hidden="true">·</span>
                <span>Ouagadougou, Burkina Faso</span>
                <span aria-hidden="true">·</span>
                <span>Architectures Offline-First</span>
              </div>

              <h1
                className="font-display font-bold tracking-tight text-white mb-6"
                style={{
                  fontSize: 'clamp(2.25rem, 4vw, 3.5rem)',
                  lineHeight: 1.1,
                  textWrap: 'balance',
                }}
              >
                {HERO_TITLE}
              </h1>

              <p className="text-base sm:text-lg text-zinc-300 leading-relaxed max-w-[65ch] mb-6">
                {HERO_MISSION} Nous bâtissons des applications mobiles compilées,
                sécurisées et autonomes hors-ligne, pensées pour offrir une fiabilité
                exemplaire aux particuliers comme aux professionnels.
              </p>

              <p className="text-sm text-zinc-400 leading-relaxed max-w-[62ch] mb-8">
                Nos deux réalisations phares —{' '}
                <strong className="text-white font-semibold">RecetteFaso</strong>{' '}
                (525 recettes authentiques) et{' '}
                <strong className="text-white font-semibold">QuickQuote PDF</strong>{' '}
                (devis et factures A4 signés hors-ligne) — sont intégralement compilées
                et disponibles en téléchargement direct au format APK.
              </p>
            </div>

            <div className="pt-2">
              <div className="flex flex-wrap items-center gap-4">
                <a
                  href="#realisations"
                  className="inline-flex items-center gap-2.5 px-6 py-3 text-sm font-semibold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Découvrir nos 2 applications</span>
                  <ArrowDownRight className="w-4 h-4" aria-hidden="true" />
                </a>

                <button
                  type="button"
                  onClick={onOpenCodeModal}
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-medium text-zinc-200 bg-[#11131A] border border-white/15 rounded-lg hover:border-amber-400/50 hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <FileCode2 className="w-4 h-4 text-amber-400" aria-hidden="true" />
                  <span>Exporter index.html autonome</span>
                </button>
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-2 text-xs text-zinc-400">
                <span>Contact direct :</span>
                <a
                  href={`mailto:${OFFICIAL_EMAIL}`}
                  className="font-mono text-zinc-200 hover:text-amber-400 underline underline-offset-4 transition-colors"
                >
                  {OFFICIAL_EMAIL}
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Dual Real Application Showcase (RecetteFaso & QuickQuote PDF) */}
          <div className="lg:col-span-5 flex">
            <div className="relative w-full overflow-hidden rounded-2xl border border-white/10 bg-[#11131A] p-5 sm:p-6 flex flex-col justify-between">
              <div className="flex items-center justify-between gap-2 pb-4 border-b border-white/10">
                <div className="flex items-center gap-2 text-xs font-mono text-amber-300">
                  <ShieldCheck className="w-4 h-4 shrink-0" aria-hidden="true" />
                  <span>APPLICATIONS OFFICIELLES COMPILÉES</span>
                </div>
                <span className="text-xs font-mono text-zinc-400">APK ANDROID</span>
              </div>

              {/* Dual Phone Screen Preview Grid using Real User Screenshots */}
              <div className="my-5 grid grid-cols-2 gap-4 items-stretch">
                {/* RecetteFaso Real Screen Preview */}
                <a
                  href="#realisations"
                  className="group flex flex-col justify-between rounded-xl bg-[#090A0F] p-3 hover:bg-[#161923] transition-colors"
                >
                  <div className="flex items-center gap-2 mb-2.5">
                    <img
                      src={recetteApp.logoUrl}
                      alt="Icône officielle RecetteFaso"
                      referrerPolicy="no-referrer"
                      className="w-7 h-7 rounded-md object-cover shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate">
                        {recetteApp.name}
                      </p>
                      <p className="text-[10px] font-mono text-amber-400 truncate">
                        525 recettes
                      </p>
                    </div>
                  </div>
                  <div className="aspect-[9/16] w-full overflow-hidden rounded-lg bg-[#161923]">
                    <img
                      src={recetteApp.imageUrl}
                      alt="Capture d'écran officielle RecetteFaso"
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover object-top group-hover:scale-[1.02] transition-transform"
                    />
                  </div>
                </a>

                {/* QuickQuote PDF Real Screen Preview */}
                <a
                  href="#realisations"
                  className="group flex flex-col justify-between rounded-xl bg-[#090A0F] p-3 hover:bg-[#161923] transition-colors"
                >
                  <div className="flex items-center gap-2 mb-2.5">
                    <img
                      src={quickQuoteApp.logoUrl}
                      alt="Icône officielle QuickQuote PDF"
                      referrerPolicy="no-referrer"
                      className="w-7 h-7 rounded-md object-cover shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-white truncate">
                        {quickQuoteApp.name}
                      </p>
                      <p className="text-[10px] font-mono text-emerald-400 truncate">
                        Devis &amp; Factures A4
                      </p>
                    </div>
                  </div>
                  <div className="aspect-[9/16] w-full overflow-hidden rounded-lg bg-[#161923]">
                    <img
                      src={quickQuoteApp.imageUrl}
                      alt="Capture d'écran officielle QuickQuote PDF"
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover object-top group-hover:scale-[1.02] transition-transform"
                    />
                  </div>
                </a>
              </div>

              <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs text-zinc-400">
                <span>21 captures d’écran officielles intégrées</span>
                <a
                  href="#realisations"
                  className="font-mono text-amber-400 hover:underline whitespace-nowrap"
                >
                  Explorer la galerie →
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column Proof Strip Below Hero Split */}
        <div className="mt-12 pt-10 border-t border-white/10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <p className="font-mono text-2xl font-semibold text-white tabular-nums whitespace-nowrap">
              2 Applications
            </p>
            <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed">
              Compilées en version stable (RecetteFaso &amp; QuickQuote PDF)
            </p>
          </div>

          <div>
            <p className="font-mono text-2xl font-semibold text-amber-400 tabular-nums whitespace-nowrap">
              100 % Hors-Ligne
            </p>
            <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed">
              525 recettes embarquées &amp; moteur PDF A4 local sans serveur
            </p>
          </div>

          <div>
            <p className="font-mono text-2xl font-semibold text-emerald-400 tabular-nums whitespace-nowrap">
              Android 8.0+
            </p>
            <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed">
              Optimisées Arm64-v8a pour smartphones d’entrée et milieu de gamme
            </p>
          </div>

          <div>
            <p className="font-mono text-2xl font-semibold text-white tabular-nums whitespace-nowrap">
              {totalDownloads.toLocaleString('fr-FR')} APK
            </p>
            <p className="mt-1.5 text-xs text-zinc-400 leading-relaxed">
              Téléchargements cumulés de nos paquets officiels vérifiés
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
