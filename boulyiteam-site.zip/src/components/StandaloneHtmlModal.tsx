import React, { useState } from 'react';
import { X, Copy, Check, Download, FileCode2 } from 'lucide-react';
import { generateStandaloneIndexHtml } from '../utils/catalog';

interface StandaloneHtmlModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const StandaloneHtmlModal: React.FC<StandaloneHtmlModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const htmlSource = generateStandaloneIndexHtml();

  const handleCopyCode = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(htmlSource);
      }
    } catch {
      // ignore clipboard errors
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadHtml = () => {
    const blob = new Blob([htmlSource], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'index.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="standalone-html-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto"
    >
      <div className="relative w-full max-w-4xl rounded-2xl border border-white/15 bg-[#11131A] p-6 sm:p-8 shadow-2xl">
        <div className="flex items-start justify-between gap-4 border-b border-white/10 pb-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-amber-400 mb-1">
              <FileCode2 className="w-4 h-4" aria-hidden="true" />
              <span>PRÊT POUR GITHUB PAGES &amp; NETLIFY</span>
            </div>
            <h2
              id="standalone-html-title"
              className="font-display text-2xl font-bold text-white"
            >
              Fichier unique index.html autonome (HTML5 + Tailwind CDN)
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Fermer la fenêtre du code source"
            className="rounded-lg border border-white/15 bg-[#161923] p-2 text-zinc-300 hover:border-white/30 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" aria-hidden="true" />
          </button>
        </div>

        <div className="py-5">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <p className="text-xs text-zinc-300">
              Copiez ou téléchargez ce fichier <code className="font-mono text-amber-400">index.html</code> complet pour un déploiement statique direct sur GitHub Pages ou Netlify.
            </p>
            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={handleCopyCode}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                {copied ? (
                  <>
                    <Check className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Code HTML copié</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                    <span>Copier index.html</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={handleDownloadHtml}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-medium text-zinc-200 bg-[#161923] border border-white/15 rounded-lg hover:border-white/30 hover:text-white transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Download className="w-3.5 h-3.5 text-amber-400" aria-hidden="true" />
                <span>Télécharger index.html</span>
              </button>
            </div>
          </div>

          <pre className="max-h-[380px] overflow-auto rounded-xl border border-white/10 bg-[#090A0F] p-4 text-xs font-mono text-zinc-300 leading-relaxed">
            <code>{htmlSource}</code>
          </pre>
        </div>

        <div className="flex justify-end border-t border-white/10 pt-4">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-zinc-300 border border-white/15 rounded-lg hover:text-white cursor-pointer"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
