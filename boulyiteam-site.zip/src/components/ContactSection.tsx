import React, { useState } from 'react';
import {
  Mail,
  Copy,
  Check,
  Send,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import {
  OFFICIAL_EMAIL,
  COLLECTIVE_NAME,
  ContactFormInput,
  validateContactForm,
} from '../utils/catalog';

export interface SubmittedInquiry extends ContactFormInput {
  id: string;
  submittedAt: string;
}

export const ContactSection: React.FC = () => {
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [form, setForm] = useState<ContactFormInput>({
    fullName: '',
    email: '',
    subject: '',
    applicationTarget: 'RecetteFaso',
    message: '',
  });
  const [errors, setErrors] = useState<
    Partial<Record<keyof ContactFormInput, string>>
  >({});
  const [submittedList, setSubmittedList] = useState<SubmittedInquiry[]>([]);

  const handleCopyEmail = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(OFFICIAL_EMAIL);
      }
    } catch {
      // Fallback handled silently
    }
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validation = validateContactForm(form);
    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});
    const newEntry: SubmittedInquiry = {
      ...form,
      id: `inq-${Date.now()}`,
      submittedAt: new Date().toLocaleTimeString('fr-FR', {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };
    setSubmittedList((prev) => [newEntry, ...prev]);
    setForm({
      fullName: '',
      email: '',
      subject: '',
      applicationTarget: form.applicationTarget,
      message: '',
    });
  };

  return (
    <section
      id="contact"
      aria-labelledby="contact-heading"
      className="bg-[#090A0F] py-20 lg:py-28"
    >
      <div className="mx-auto max-w-[1200px] px-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Column: Official Email & Direct Contact Card */}
          <div className="lg:col-span-5">
            <p className="text-xs font-medium text-amber-400 mb-2">
              ÉCHANGES &amp; ASSISTANCE TECHNIQUE
            </p>
            <h2
              id="contact-heading"
              className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white mb-4"
              style={{ textWrap: 'balance' }}
            >
              03. Contactez {COLLECTIVE_NAME}
            </h2>
            <p className="text-sm sm:text-base text-zinc-300 leading-relaxed mb-8">
              Une question sur l’installation de <strong className="text-white">RecetteFaso</strong> ou de{' '}
              <strong className="text-white">QuickQuote PDF</strong> ? Un retour
              d’expérience ou une demande de partenariat professionnel ? Notre
              équipe vous répond directement via notre adresse officielle.
            </p>

            {/* Official Email Highlight Box */}
            <div className="rounded-2xl border border-white/10 bg-[#11131A] p-6 mb-6">
              <div className="flex items-center gap-2.5 text-xs font-mono text-zinc-400 mb-2">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" aria-hidden="true" />
                <span>ADRESSE E-MAIL OFFICIELLE DU COLLECTIF</span>
              </div>

              <a
                href={`mailto:${OFFICIAL_EMAIL}`}
                data-testid="official-email-link"
                className="font-mono text-base sm:text-lg font-semibold text-amber-400 hover:text-amber-300 underline underline-offset-4 break-all block mb-5"
              >
                {OFFICIAL_EMAIL}
              </a>

              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={handleCopyEmail}
                  className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  {copiedEmail ? (
                    <>
                      <Check className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Adresse copiée</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" aria-hidden="true" />
                      <span>Copier l’adresse e-mail</span>
                    </>
                  )}
                </button>

                <a
                  href={`mailto:${OFFICIAL_EMAIL}?subject=Contact%20Boulyi%20Team%20D%C3%A9velopper`}
                  className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium text-zinc-200 bg-[#161923] border border-white/15 rounded-lg hover:border-white/30 hover:text-white transition-colors whitespace-nowrap shrink-0"
                >
                  <span>Ouvrir la messagerie</span>
                </a>
              </div>
            </div>

            <div className="text-xs text-zinc-400 space-y-1.5">
              <p>Disponibilité : Lundi – Samedi · 08h00 à 19h00 (GMT / Ouagadougou)</p>
              <p>Support APK garanti pour RecetteFaso (v2.4.0) et QuickQuote PDF (v1.0.0 Pro Offline)</p>
            </div>
          </div>

          {/* Right Column: Interactive Validated Inquiry Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl border border-white/10 bg-[#11131A] p-6 sm:p-8">
              <h3 className="font-display text-xl font-bold text-white mb-2">
                Envoyer un message rapide à l’équipe
              </h3>
              <p className="text-xs text-zinc-400 mb-6">
                Préparez et enregistrez votre demande directement ci-dessous.
              </p>

              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="contact-fullname"
                      className="block text-xs font-medium text-zinc-300 mb-2"
                    >
                      Nom complet
                    </label>
                    <input
                      id="contact-fullname"
                      type="text"
                      value={form.fullName}
                      onChange={(e) =>
                        setForm((prev) => ({ ...prev, fullName: e.target.value }))
                      }
                      placeholder="Ex: Issouf Ouédraogo"
                      className="w-full rounded-lg border border-white/15 bg-[#090A0F] px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:border-amber-400 focus:outline-none"
                    />
                    {errors.fullName && (
                      <p
                        role="alert"
                        className="mt-1.5 flex items-center gap-1.5 text-xs text-red-400"
                      >
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span>{errors.fullName}</span>
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="contact-email"
                      className="block text-xs font-medium text-zinc-300 mb-2"
                    >
                      Votre adresse e-mail
                    </label>
                    <input
                      id="contact-email"
                      type="email"
                      value={form.email}
                      onChange={(e) =>
                        setForm((prev) => ({ ...prev, email: e.target.value }))
                      }
                      placeholder="vous@domaine.com"
                      className="w-full rounded-lg border border-white/15 bg-[#090A0F] px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:border-amber-400 focus:outline-none"
                    />
                    {errors.email && (
                      <p
                        role="alert"
                        className="mt-1.5 flex items-center gap-1.5 text-xs text-red-400"
                      >
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span>{errors.email}</span>
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="contact-target"
                      className="block text-xs font-medium text-zinc-300 mb-2"
                    >
                      Application concernée
                    </label>
                    <select
                      id="contact-target"
                      value={form.applicationTarget}
                      onChange={(e) =>
                        setForm((prev) => ({
                          ...prev,
                          applicationTarget: e.target
                            .value as ContactFormInput['applicationTarget'],
                        }))
                      }
                      className="w-full rounded-lg border border-white/15 bg-[#090A0F] px-3.5 py-2.5 text-sm text-white focus:border-amber-400 focus:outline-none"
                    >
                      <option value="RecetteFaso">RecetteFaso (APK v2.4.0)</option>
                      <option value="QuickQuote PDF">
                        QuickQuote PDF (APK v1.0.0 Pro Offline)
                      </option>
                      <option value="Collaboration Générale">
                        Collaboration Générale
                      </option>
                    </select>
                  </div>

                  <div>
                    <label
                      htmlFor="contact-subject"
                      className="block text-xs font-medium text-zinc-300 mb-2"
                    >
                      Objet du message
                    </label>
                    <input
                      id="contact-subject"
                      type="text"
                      value={form.subject}
                      onChange={(e) =>
                        setForm((prev) => ({ ...prev, subject: e.target.value }))
                      }
                      placeholder="Ex: Retour sur QuickQuote PDF"
                      className="w-full rounded-lg border border-white/15 bg-[#090A0F] px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:border-amber-400 focus:outline-none"
                    />
                    {errors.subject && (
                      <p
                        role="alert"
                        className="mt-1.5 flex items-center gap-1.5 text-xs text-red-400"
                      >
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                        <span>{errors.subject}</span>
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="contact-message"
                    className="block text-xs font-medium text-zinc-300 mb-2"
                  >
                    Votre message
                  </label>
                  <textarea
                    id="contact-message"
                    rows={4}
                    value={form.message}
                    onChange={(e) =>
                      setForm((prev) => ({ ...prev, message: e.target.value }))
                    }
                    placeholder="Décrivez votre besoin ou votre question concernant nos applications..."
                    className="w-full rounded-lg border border-white/15 bg-[#090A0F] px-3.5 py-2.5 text-sm text-white placeholder:text-zinc-500 focus:border-amber-400 focus:outline-none"
                  />
                  {errors.message && (
                    <p
                      role="alert"
                      className="mt-1.5 flex items-center gap-1.5 text-xs text-red-400"
                    >
                      <AlertCircle className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                      <span>{errors.message}</span>
                    </p>
                  )}
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
                  <p className="text-xs text-zinc-400">
                    Destinataire :{' '}
                    <span className="font-mono text-zinc-200">{OFFICIAL_EMAIL}</span>
                  </p>
                  <button
                    type="submit"
                    className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-zinc-950 bg-amber-400 rounded-lg hover:bg-amber-300 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <Send className="w-4 h-4" aria-hidden="true" />
                    <span>Envoyer le message</span>
                  </button>
                </div>
              </form>

              {/* Submitted Messages Confirmation Log */}
              {submittedList.length > 0 && (
                <div
                  data-testid="submitted-inquiries-list"
                  className="mt-6 pt-6 border-t border-white/10 space-y-3"
                >
                  <div className="flex items-center gap-2 text-xs font-medium text-emerald-400">
                    <CheckCircle2 className="w-4 h-4 shrink-0" aria-hidden="true" />
                    <span>
                      Message transmis pour {OFFICIAL_EMAIL} ({submittedList.length})
                    </span>
                  </div>
                  {submittedList.map((item) => (
                    <div
                      key={item.id}
                      className="rounded-lg border border-white/10 bg-[#090A0F] p-4 text-xs"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 text-zinc-400 mb-1">
                        <span className="font-semibold text-white">
                          {item.fullName} ({item.email})
                        </span>
                        <span className="font-mono">
                          {item.applicationTarget} · {item.submittedAt}
                        </span>
                      </div>
                      <p className="text-amber-400 font-medium mb-1">
                        Objet : {item.subject}
                      </p>
                      <p className="text-zinc-300">{item.message}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
