import React from 'react';
import { WifiOff, Cpu, ShieldCheck, Layers } from 'lucide-react';

export const EngineeringSection: React.FC = () => {
  return (
    <section
      id="ingenierie"
      aria-labelledby="ingenierie-heading"
      className="border-b border-white/10 bg-[#090A0F] py-20 lg:py-24"
    >
      <div className="mx-auto max-w-[1200px] px-6">
        <div className="max-w-2xl mb-14">
          <p className="text-xs font-medium text-amber-400 mb-2">
            STANDARDS TECHNIQUES · RÉALITÉS DU TERRAIN
          </p>
          <h2
            id="ingenierie-heading"
            className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white mb-4"
            style={{ textWrap: 'balance' }}
          >
            02. Architecture Mobile Résiliente &amp; Offline-First
          </h2>
          <p className="text-sm sm:text-base text-zinc-400 leading-relaxed">
            Nos applications <strong className="text-zinc-200">RecetteFaso</strong>{' '}
            et <strong className="text-zinc-200">QuickQuote PDF</strong> sont
            forgées selon des principes d’ingénierie stricts adaptés aux réseaux
            mobiles fluctuants et aux exigences de sécurité modernes.
          </p>
        </div>

        {/* Asymmetric Bento Grid (col-span-2 alongside col-span-1) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Primary Wide Card: col-span-2 */}
          <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-[#11131A] p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 text-amber-400 mb-4">
                <WifiOff className="w-5 h-5 shrink-0" aria-hidden="true" />
                <span className="font-mono text-xs">
                  01. AUTONOMIE RÉSEAU &amp; PERSISTANCE LOCALE
                </span>
              </div>
              <h3 className="font-display text-xl sm:text-2xl font-bold text-white mb-3">
                Conçues pour fonctionner sans interruption, même hors couverture 3G/4G
              </h3>
              <p className="text-sm sm:text-base text-zinc-300 leading-relaxed max-w-[65ch]">
                Au Burkina Faso comme dans toute la sous-région, une application
                professionnelle ne doit jamais bloquer l’utilisateur lorsque la
                connexion mobile faiblit. RecetteFaso embarque l’intégralité de sa
                base culinaire dans un moteur SQLite local indexé, tandis que
                QuickQuote PDF compile ses documents financiers en PDF vectoriel
                directement sur le processeur du téléphone.
              </p>
            </div>
            <div className="mt-8 pt-5 border-t border-white/10 flex flex-wrap items-center gap-6 text-xs font-mono text-zinc-400">
              <span>Latence de lecture locale : &lt; 8 ms</span>
              <span aria-hidden="true">·</span>
              <span>Consommation data requise à l’usage : 0 Mo</span>
            </div>
          </div>

          {/* Secondary Card: col-span-1 */}
          <div className="rounded-2xl border border-white/10 bg-[#11131A] p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 text-emerald-400 mb-4">
                <ShieldCheck className="w-5 h-5 shrink-0" aria-hidden="true" />
                <span className="font-mono text-xs">02. SÉCURITÉ APK</span>
              </div>
              <h3 className="font-display text-xl font-bold text-white mb-3">
                Signature cryptographique V2 / V3
              </h3>
              <p className="text-sm text-zinc-300 leading-relaxed">
                Chaque fichier APK distribué par Boulyi Team Développer est
                compilé en mode Release, optimisé via R8/ProGuard et accompagné
                de son empreinte SHA-256 publique.
              </p>
            </div>
            <div className="mt-8 pt-5 border-t border-white/10 text-xs font-mono text-emerald-400">
              Intégrité vérifiable avant installation
            </div>
          </div>

          {/* Third Card: col-span-1 */}
          <div className="rounded-2xl border border-white/10 bg-[#11131A] p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 text-amber-400 mb-4">
                <Cpu className="w-5 h-5 shrink-0" aria-hidden="true" />
                <span className="font-mono text-xs">03. SOBRIÉTÉ MATÉRIELLE</span>
              </div>
              <h3 className="font-display text-xl font-bold text-white mb-3">
                Fluidité 60 FPS sur tous les appareils
              </h3>
              <p className="text-sm text-zinc-300 leading-relaxed">
                Empreinte mémoire maîtrisée et binaires compacts (&lt; 20 Mo)
                garantissant un téléchargement rapide et une exécution fluide dès
                Android 8.0.
              </p>
            </div>
            <div className="mt-8 pt-5 border-t border-white/10 text-xs font-mono text-zinc-400">
              Architecture Arm64-v8a native
            </div>
          </div>

          {/* Fourth Wide Card: col-span-2 */}
          <div className="lg:col-span-2 rounded-2xl border border-white/10 bg-[#11131A] p-8 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 text-emerald-400 mb-4">
                <Layers className="w-5 h-5 shrink-0" aria-hidden="true" />
                <span className="font-mono text-xs">
                  04. EXPÉRIENCE UTILISATEUR &amp; INTÉGRATION ADMOB MAÎTRISÉE
                </span>
              </div>
              <h3 className="font-display text-xl sm:text-2xl font-bold text-white mb-3">
                Interfaces sombres ergonomiques et bannières non-intrusives
              </h3>
              <p className="text-sm sm:text-base text-zinc-300 leading-relaxed max-w-[65ch]">
                Nos interfaces privilégient la lisibilité, l’économie de batterie
                sur écrans OLED et une hiérarchie visuelle immédiate. L’intégration
                des bannières Google AdMob est isolée dans des conteneurs dédiés
                à hauteur fixe avec gestion gracieuse du mode hors-ligne, sans
                jamais perturber la saisie d’un devis ou la lecture d’une recette.
              </p>
            </div>
            <div className="mt-8 pt-5 border-t border-white/10 flex flex-wrap items-center gap-6 text-xs font-mono text-zinc-400">
              <span>Zéro saut de mise en page (CLS = 0)</span>
              <span aria-hidden="true">·</span>
              <span>Respect strict de la vie privée</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
